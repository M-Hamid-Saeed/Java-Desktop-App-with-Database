package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class courseController implements Initializable {
    @FXML
    private TableColumn<course, Float> cf;

    @FXML
    private TableColumn<course, Integer> courid;
    Connection con;

    @FXML
    private TextField courseFee;

    @FXML
    private TextField courseName;

    @FXML
    private TableView<course> courseTable;

    @FXML
    private TextField courseid;

    @FXML
    private TableColumn<course, String> coursen;

    @FXML
    private TextField searchCourse;
    PreparedStatement stmt;
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    public static final ObservableList<course> courses = FXCollections.observableArrayList();

    public static final List<course> courseList = new ArrayList<>();
    @FXML
    void AddCourse(ActionEvent event) throws SQLException {
        String query = String.format("INSERT INTO dbo.course (courseID,courseName,courseFee)" +
                "VALUES (?,?,?)");
        if(isfound(Integer.parseInt(courseid.getText())))
            generateAlert(Alert.AlertType.CONFIRMATION,"Course Already Exist","");
        else {
            stmt = con.prepareStatement(query);
            stmt.setString(1, courseid.getText());
            stmt.setString(2, courseName.getText());
            stmt.setString(3, courseFee.getText());
            stmt.execute();
            generateAlert(Alert.AlertType.CONFIRMATION,"Course Added Successfully","");
        }
        try{
            initList("Select * From course");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        courseTable.setItems(courses);

    }

    void initList(String query) throws IOException {
        courseList.clear();
        courses.clear();
        //String query = ("Select * From member");
        try {

            stmt = con.prepareStatement(query);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                int memID = result.getInt("courseID");
                String n = result.getString("courseName");
                float sn = result.getFloat("courseFee");
                courses.add(new course(memID,n,sn));
                courseList.add(new course(memID,n,sn));
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }
    private boolean isfound(int ID) throws SQLException {
        String queryString = String.format("SELECT courseID from course WHERE courseID='%d'",ID);
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        return results.next();

    }

    @FXML
    void deleterecord(ActionEvent event) throws SQLException {
        String queryString = String.format("Delete from course where courseID = '%s' ",searchCourse.getText());
        if(isfound(Integer.parseInt(searchCourse.getText()))){
        try{
        Statement statement = con.createStatement();
        statement.execute(queryString);}
        catch (SQLException e) {
            throw new RuntimeException(e);

        }}
        else
            generateAlert(Alert.AlertType.CONFIRMATION,"Not Found","");
        try{
            initList("Select * From course");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        courseTable.setItems(courses);

    }

    @FXML
    void searchCourse(ActionEvent event) {
        try{
            initList(String.format("Select * From course where courseID = '%s'",searchCourse.getText()));
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        courseTable.setItems(courses);

    }


    @FXML
    void updaterecord(ActionEvent event) {
        String query = String.format("UPDATE course SET  courseID = ? , courseName = ? , courseFee = ?   where courseID = ?");
        try {
            stmt = con.prepareStatement(query);
            stmt.setInt(1,Integer.parseInt(courseid.getText()));
            stmt.setString(2,courseName.getText());
            stmt.setString(3,courseFee.getText());
            stmt.setInt(4,Integer.parseInt(searchCourse.getText()));
            stmt.execute();
            generateAlert(Alert.AlertType.CONFIRMATION,"Updated Successfully","");
        } catch (SQLException e) {
            generateAlert(Alert.AlertType.ERROR,"Cannot Update","");
            throw new RuntimeException(e);
        }
        try{
            initList("Select * From course");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        courseTable.setItems(courses);

    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            con = DriverManager.getConnection(ConnectionURL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        courid.setCellValueFactory(new PropertyValueFactory<>("courseid"));
        coursen.setCellValueFactory(new PropertyValueFactory<>("coursename"));
        cf.setCellValueFactory(new PropertyValueFactory<>("coursef"));
        try{
            initList("Select * From course");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        courseTable.setItems(courses);

    }
}
