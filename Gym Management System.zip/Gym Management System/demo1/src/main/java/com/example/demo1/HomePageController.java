package com.example.demo1;

import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HomePageController implements Initializable {
    @FXML
    private Button mainmenu;
    @FXML
    private Pane holdPane;

    @FXML
    private Label adminName ;

    @FXML
    private Button bill;

    @FXML
    private Button dash;

    @FXML
    private Button employeeRegistration;

    @FXML
    private Button checkout;

//    @FXML
//    private AnchorPane holdPane;

    @FXML
    private Button memberRegistration;

    private AnchorPane Pane;

    public static String name;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //adminName.setText(name);
        //adminName.setBackground(Background.fill(Color.WHITE));
    }

    private void setNode(Node node) {
        holdPane.getChildren().clear();
        holdPane.getChildren().add(node);
        FadeTransition ft = new FadeTransition(Duration.millis(2000));
        ft.setNode(node);
        ft.setFromValue(0.5);
        ft.setToValue(1);
        ft.setCycleCount(1);
        ft.setAutoReverse(false);
        ft.play();

    }

    public void memberregistrationClicked(javafx.event.ActionEvent actionEvent) throws IOException {
        employeeRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        checkout.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        bill.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        dash.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
         Pane = FXMLLoader.load(getClass().getResource("memberMainPage.fxml"));
        memberRegistration.setStyle("-fx-background-color:  #2e2e2f; -fx-text-fill: #e8e5e5");
        setNode(Pane);

//        memberRegistration.setStyle("-fx-background-color:  #2D3347; -fx-text-fill: #ffffff");
//        memberRegistration.getScene().getWindow().hide();
//        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MemberDetails.fxml"));
//        Scene scene = new Scene(fxmlLoader.load(), 800, 800);
//        Stage stage = new Stage();
//        stage.setTitle("Dashboard");
//        stage.setScene(scene);
//        stage.show();
    }

    public void employeeRegistrationclicked(javafx.event.ActionEvent actionEvent) {
        try {
            memberRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
            checkout.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
            bill.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
            Pane = FXMLLoader.load(getClass().getResource("employeemain.fxml"));
            dash.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
            setNode(Pane);
            employeeRegistration.setStyle("-fx-background-color:  #2e2e2f; -fx-text-fill: #e8e5e5");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void createCheckOut(javafx.event.ActionEvent actionEvent) throws IOException {
        memberRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        employeeRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        bill.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        dash.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
         Pane = FXMLLoader.load(getClass().getResource("payment.fxml"));
        setNode(Pane);
        checkout.setStyle("-fx-background-color:  #2D3347; -fx-text-fill: #ffffff");
    }

    public void createCustomerBill(javafx.event.ActionEvent actionEvent) throws IOException {
        memberRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        employeeRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        checkout.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        dash.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        Pane = FXMLLoader.load(getClass().getResource("income.fxml"));
        setNode(Pane);
        bill.setStyle("-fx-background-color:  #2D3347; -fx-text-fill: #ffffff");

    }

    public void createDash(javafx.event.ActionEvent actionEvent) throws IOException {
        memberRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        employeeRegistration.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        checkout.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
        bill.setStyle("-fx-background-color:  #ffffff; -fx-text-fill: #000000");
         Pane = FXMLLoader.load(getClass().getResource("Dashboard.fxml"));
        setNode(Pane);
        dash.setStyle("-fx-background-color:  #2D3347; -fx-text-fill: #ffffff");
//        memberRegistration.getScene().getWindow().hide();
//        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
//        Scene scene = new Scene(fxmlLoader.load(), 800, 800);
//        Stage stage = new Stage();
//        stage.setTitle("Dashboard");
//        stage.setScene(scene);
//        stage.show();
    }

    public void handleLogout(MouseEvent event) throws IOException {
        bill.getScene().getWindow().hide();
        Stage login = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(root);
        login.setScene(scene);
        login.show();
    }
    @FXML
    void mainmenuclicked(ActionEvent event) {
        System.out.println("MAIN CLICKED");

    }
}
