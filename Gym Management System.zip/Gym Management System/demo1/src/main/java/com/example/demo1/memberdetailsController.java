package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class memberdetailsController implements Initializable{


    @FXML
    private TextField address;

    @FXML
    private Label amount;



    @FXML
    private DatePicker joiningdate;

    @FXML
    private ImageView logout;

    @FXML
    private TextField memberId;

    @FXML
    private TextField firstName;

    @FXML
    private TextField phoneNo;

    @FXML
    private Button saveButton;

    @FXML
    private TextField surname;

    PreparedStatement stmt;
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";

    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }


    @FXML
    void saveButtonClicked(ActionEvent event) throws Exception {
        String cid = null;
        Connection con = DriverManager.getConnection(ConnectionURL);
        Statement statement = con.createStatement();

        String date = joiningdate.getEditor().getText();
        int id = Integer.parseInt(memberId.getText());
        String name = firstName.getText();
        String phoneno = phoneNo.getText();
        String query = String.format("INSERT INTO dbo.member (memberID,mNAME,mSurname," +
                "mAddress,mPhoneNo,mJoiningData) " +
                "VALUES (?,?,?,?,?,?)");
        if(isfound(id,name,con,phoneno))
            generateAlert(Alert.AlertType.INFORMATION, "Already Found", "");
        else{

        stmt = con.prepareStatement(query);
       stmt.setString(1,memberId.getText());
        stmt.setString(2,name);
        stmt.setString(3,surname.getText());
        stmt.setString(4,address.getText());
        stmt.setString(5, phoneno);
        //stmt.setString(6,gen);
        stmt.setString(6,date);
        stmt.executeUpdate();


        generateAlert(Alert.AlertType.CONFIRMATION,"Member Inserted","");
        }
    }
    @FXML
    void backclicked(MouseEvent event) throws IOException {
        saveButton.getScene().getWindow().hide();
        Stage login = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
        Scene scene = new Scene(root);
        login.setScene(scene);
        login.show();

    }
    private boolean isfound(int ID, String name,Connection con,String phoneNO) throws SQLException {
        String queryString = String.format("SELECT memberID,mName FROM dbo.member WHERE memberID='%d' OR mName='%s' AND mPhoneNo = '%s'",ID,name,phoneNO);
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        if(results.next())
            return true;
        else
            return false;

    }

}
