package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class paymentController implements Initializable {
    @FXML
    private TableColumn<paymentData, Float> cfee;

    @FXML
    private TableColumn<paymentData, String> cname;
    @FXML
    private TableColumn<paymentData, Integer> memid;

    @FXML
    private TableColumn<paymentData, String> memname;
    @FXML
    private TableColumn<paymentData, Date> paydate;
    @FXML
    private TableView<paymentData> paymentTable;
    @FXML
    private Button showActive;

    @FXML
    private TableColumn<paymentData, String> status;
    @FXML
    private TableColumn<paymentData, String> trainer;

    @FXML
    private RadioButton active;

    @FXML
    private ComboBox<String> course;

    @FXML
    private ComboBox<String> employeeName;

    @FXML
    private Label id;

    @FXML
    private DatePicker stausDate;
    @FXML
    private Label totalFee;
    @FXML
    private Label name;

    @FXML
    private Button save;
    int eid;
    int cid;
    PreparedStatement stmt;

    Connection con;
    @FXML
    private DatePicker From;

    @FXML
    private DatePicker To;

    @FXML
    private DatePicker paymentDate;
    @FXML
    private TextField searchMember;
    @FXML
    private RadioButton unactive;
    @FXML
    private Button update;
    String value;

  //  String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustSer
  String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    @FXML
    void showActiveClicked(ActionEvent event) {
        String query2 = "select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
        try {
            initList(query2);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);

    }
    @FXML
    void showfromdateclicked(ActionEvent event) {
        String fromDate = From.getEditor().getText();
        String tod = To.getEditor().getText();
        String query2 = String.format("select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus" +
                " from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID) " +
                "where payment.paymentDate>= '%s' and payment.paymentDate<= '%s'",fromDate,tod);
        try {
            initList(query2);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);

    }

    @FXML
    void updateClicked(ActionEvent event) throws SQLException {
        getValues();
        if(active.isSelected())
            value = "Active";
        if(unactive.isSelected())
            value = "UnActive";
        con = DriverManager.getConnection(ConnectionURL);
        String date = paymentDate.getEditor().getText();
        String query = String.format("INSERT INTO dbo.payment (memberID,employeeID,courseID," +
                "paymentDate,ActiveStatus) " +
                "VALUES (?,?,?,?,?)");
            stmt = con.prepareStatement(query);
            stmt.setString(1,id.getText());
            stmt.setInt(2,eid);
            stmt.setInt(3,cid);
            stmt.setString(4,date);
            stmt.setString(5, value);
            stmt.executeUpdate();
        String querystring = "select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
        try {
            initList(querystring);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);
            generateAlert(Alert.AlertType.INFORMATION, "Details Added Successfully", "");

    }
    @FXML
    void deleteall(ActionEvent event) throws SQLException {
        con = DriverManager.getConnection(ConnectionURL);
        String date = paymentDate.getEditor().getText();
        String query = String.format("Delete from payment ");
        stmt = con.prepareStatement(query);
        stmt = con.prepareStatement(query);
        stmt.execute();
        String querystring = "select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
        try {
            initList(querystring);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);
        generateAlert(Alert.AlertType.INFORMATION, "Record Deleted Successfully", "");

    }
    @FXML
    void deleterecord(ActionEvent event) throws SQLException {
        con = DriverManager.getConnection(ConnectionURL);
        String date = paymentDate.getEditor().getText();
        String query = String.format("Delete from payment where memberID = ? and paymentDate = ? ");
        try{
        stmt = con.prepareStatement(query);
        stmt.setString(1,id.getText());
        stmt.setString(2,stausDate.getEditor().getText());
        stmt.execute();}
        catch (Exception ex){
            generateAlert(Alert.AlertType.ERROR,"Please Select Payment Date to Delete Specific Record","");
        }
        String querystring = "select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
        try {
            initList(querystring);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);
        generateAlert(Alert.AlertType.INFORMATION, "Record Deleted Successfully", "");
    }
    @FXML
    void updaterecord(ActionEvent event) throws SQLException {
        getValues();
        if(active.isSelected())
            value = "Active";
        if(unactive.isSelected())
            value = "UnActive";
        con = DriverManager.getConnection(ConnectionURL);
        String date = paymentDate.getEditor().getText();
        String query = String.format("UPDATE payment SET  employeeID = ? , courseID = ? , paymentDate = ? , ActiveStatus = ?   where memberID = ? and paymentDate = ?");
        stmt = con.prepareStatement(query);
        stmt.setInt(1,eid);
        stmt.setInt(2,cid);
        stmt.setString(3,date);
        stmt.setString(4, value);
        stmt.setString(5,id.getText());
        stmt.setString(6,stausDate.getEditor().getText());
        stmt.executeUpdate();

        String querystring = "select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
        try {
            initList(querystring);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);
        generateAlert(Alert.AlertType.INFORMATION, "Details Updated Successfully", "");
    }


    @FXML
    void saveclicked(ActionEvent event) throws SQLException {
        getValues();
        if(active.isSelected())
            value = "Active";
        if(unactive.isSelected())
            value = "UnActive";
        Connection con = DriverManager.getConnection(ConnectionURL);
        String date = paymentDate.getEditor().getText();
        String querystring = "select member.memberID,member.mName,course.courseName,courseFee," +
                "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
        String query = String.format("INSERT INTO dbo.payment (memberID,employeeID,courseID," +
                "paymentDate,ActiveStatus) " +
                "VALUES (?,?,?,?,?)");
        if(isfound(Integer.parseInt(id.getText()),con)){
            String query2 = String.format("UPDATE payment SET ActiveStatus = ? where memberID = ? and paymentDate = ?");
            stmt = con.prepareStatement(query2);
            stmt.setString(1,value);
            stmt.setInt(2, Integer.parseInt(id.getText()));
            stmt.setString(3,stausDate.getEditor().getText());
            stmt.executeUpdate();
            try {
                initList(querystring);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            paymentTable.setItems(members);
            }
        else{
            stmt = con.prepareStatement(query);
            stmt.setString(1,id.getText());
            stmt.setInt(2,eid);
            stmt.setInt(3,cid);
            stmt.setString(4,date);
            stmt.setString(5, value);
            stmt.executeUpdate();

            try {
                initList(querystring);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            paymentTable.setItems(members);
        }



    }

    void getValues(){
        //String date = paymentDate.getEditor().getText();
        id.getText();
        name.getText();
        String ename = employeeName.getSelectionModel().getSelectedItem();
        String coursename = course.getSelectionModel().getSelectedItem();
        String query = String.format("Select EmployeeID from Employee where eName = '%s'",ename);
        String query2 = String.format("Select courseID from course where courseName = '%s'",coursename);
        try {
            Connection con = DriverManager.getConnection(ConnectionURL);
            Statement statement = con.createStatement();
            ResultSet results = statement.executeQuery(query);
            while (results.next())
                eid = results.getInt("EmployeeID");
            ResultSet results2 = statement.executeQuery(query2);
            while(results2.next())
                cid=  results2.getInt("courseID");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @FXML
    void searchClicked(ActionEvent event) throws SQLException, IOException {
        Connection con = DriverManager.getConnection(ConnectionURL);
        //Statement statement = con.createStatement();
        String queryString = String.format("SELECT memberID,mName FROM dbo.member WHERE memberID='%d'",Integer.parseInt(searchMember.getText()));
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        if(results.next()) {
            id.setText(results.getString(1));
            name.setText(results.getString(2));
            String query2 = String.format("select member.memberID,member.mName,course.courseName,courseFee," +
                    "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                    " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID) where payment.memberID = '%s'",searchMember.getText());
            initList(query2);
        }
        else{
            generateAlert(Alert.AlertType.INFORMATION, "Member Not Existed", "");

        }
        paymentTable.setItems(members);
        }


    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }

    private boolean isfound(int ID, Connection con) throws SQLException {
        String queryString = String.format("SELECT memberID FROM dbo.payment WHERE memberID='%d'",ID);
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        if(results.next())
            return true;
        else
            return false;

    }
    @FXML
    void courseSelected(ActionEvent event) throws SQLException {
        String course1 = course.getSelectionModel().getSelectedItem();
        String queryString = String.format("Select courseFee from course where courseName = '%s'",course1);
        Connection con = DriverManager.getConnection(ConnectionURL);
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        while (results.next()){
            totalFee.setText(String.valueOf(results.getFloat("courseFee")));

        }

    }
    public static final ObservableList<paymentData> members = FXCollections.observableArrayList();

    public static final List<paymentData> memberList = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String queryString = String.format("SELECT courseName from course");
        String queryString2 = String.format("SELECT eName from Employee where Role = 'Trainer' ");
//
        try {
            con = DriverManager.getConnection(ConnectionURL);
            Statement statement = con.createStatement();
            ResultSet results = statement.executeQuery(queryString);
            while (results.next())
                course.getItems().add(results.getString("courseName"));
            ResultSet results2 = statement.executeQuery(queryString2);
            while(results2.next())
                employeeName.getItems().add(results2.getString(1));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        memid.setCellValueFactory(new PropertyValueFactory<>("memberid"));
        memname.setCellValueFactory(new PropertyValueFactory<>("membername"));
        cname.setCellValueFactory(new PropertyValueFactory<>("coursename"));
        cfee.setCellValueFactory(new PropertyValueFactory<>("courseFee"));
        trainer.setCellValueFactory(new PropertyValueFactory<>("trainername"));
        paydate.setCellValueFactory(new PropertyValueFactory<>("paymentdate"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        try{
            con = DriverManager.getConnection(ConnectionURL);
            String query2 = "select member.memberID,member.mName,course.courseName,courseFee," +
                    "Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join" +
                    " course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)";
            initList(query2);
        }
        catch (IOException | SQLException e) {
            throw new RuntimeException(e);
        }
        paymentTable.setItems(members);
    }
    void initList(String query) throws IOException {
        memberList.clear();
        members.clear();
        //String query = ("Select * From member");
        try {

            stmt = con.prepareStatement(query);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                int memID = result.getInt("memberID");
                String n = result.getString("mName");
                String cn = result.getString("courseName");
                float coufee = result.getFloat("courseFee");
                String tn = result.getString("eName");
                Date d = result.getDate("paymentDate");
                String stat = result.getString("ActiveStatus");
                members.add(new paymentData(memID, n, cn, coufee, tn, d, stat));
                memberList.add(new paymentData(memID, n, cn, coufee, tn, d, stat));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
