package com.example.demo1;

import java.util.Date;

//
//import javafx.beans.property.SimpleIntegerProperty;
//import javafx.beans.property.SimpleStringProperty;
//
public class Member{
    private int memberID;
    private String memberName;
    private String memberSurname;
    public Member(int memberID, String memberName, String memberSurname, String memberAddress, long memberPhoneNo, Date memberJoiningDate) {
        this.memberID = memberID;
        this.memberName = memberName;
        this.memberSurname = memberSurname;
        this.memberAddress = memberAddress;
        this.memberPhoneNo = memberPhoneNo;
        this.memberJoiningDate = memberJoiningDate;
    }


    public int getMemberID() {
        return memberID;
    }

    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberSurname() {
        return memberSurname;
    }

    public void setMemberSurname(String memberSurname) {
        this.memberSurname = memberSurname;
    }

    public String getMemberAddress() {
        return memberAddress;
    }

    public void setMemberAddress(String memberAddress) {
        this.memberAddress = memberAddress;
    }

    public long getMemberPhoneNo() {
        return memberPhoneNo;
    }


    public void setMemberPhoneNo(long memberPhoneNo) {
        this.memberPhoneNo = memberPhoneNo;
    }

    public Date getMemberJoiningDate() {
        return memberJoiningDate;
    }

    public void setMemberJoiningDate(Date memberJoiningDate) {
        this.memberJoiningDate = memberJoiningDate;
    }

    private String memberAddress;
    private long memberPhoneNo;
    private Date memberJoiningDate;


}