package com.example.demo1;

public class course {
    private int courseid;
    private String coursename;
    private float coursef;

    public course(int courseid, String coursename, float coursef) {
        this.courseid = courseid;
        this.coursename = coursename;
        this.coursef = coursef;
    }

    public int getCourseid() {
        return courseid;
    }

    public void setCourseid(int courseid) {
        this.courseid = courseid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public float getCoursef() {
        return coursef;
    }

    public void setCoursef(float coursef) {
        this.coursef = coursef;
    }
}
