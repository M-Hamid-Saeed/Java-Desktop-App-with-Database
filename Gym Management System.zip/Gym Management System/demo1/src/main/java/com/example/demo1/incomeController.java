package com.example.demo1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class incomeController implements Initializable {
    Connection con ;
    Statement statement;
    PreparedStatement stmt;

    @FXML
    private Label earning;

    @FXML
    private DatePicker from;

    @FXML
    private DatePicker to;

    @FXML
    void showClicked(ActionEvent event) {
        String query = String.format(" select distinct sum(courseFee) as Income from course inner join payment on payment.courseID = course.courseID");
        showData(query);

    }

    @FXML
    void showFromClicked(ActionEvent event) {
        String fromd = from.getEditor().getText();
        String tod = to.getEditor().getText();
        String query = String.format("select distinct sum(courseFee) as Income from course inner join payment on payment.courseID = course.courseID where payment.paymentDate >= '%s' and payment.paymentDate<= '%s'",fromd,tod);
        showData(query);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String query = String.format(" select distinct sum(courseFee) as Income from course inner join payment on payment.courseID = course.courseID");
        showData(query);

    }
        void showData(String query){

            DBconnection db = new DBconnection();
            try {
                statement = db.connectingDB();
                ResultSet results = statement.executeQuery(query);
                while (results.next())
                    earning.setText(results.getString("Income"));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }


    }
