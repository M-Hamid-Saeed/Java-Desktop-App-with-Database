package com.example.demo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBconnection {
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    public Statement connectingDB() throws Exception {
        Connection con = DriverManager.getConnection(ConnectionURL);
        Statement stmt = con.createStatement();
        System.out.println("Connected");
        return stmt;
    }
}
