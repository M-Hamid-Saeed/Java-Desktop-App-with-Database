package com.example.demo1;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class updateDelMember implements Initializable{

    @FXML
    private TextField address;

    Connection con;

    @FXML
    private DatePicker joiningdate;

    @FXML
    private TextField memberId;

    @FXML
    private TextField firstName;

    @FXML
    private TextField phoneNo;

    @FXML
    private Button update;
    @FXML
    private Button delete;

    @FXML
    private TextField surname;
    @FXML
    private TextField searchmember;


    PreparedStatement stmt;
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            con = DriverManager.getConnection(ConnectionURL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        update.setVisible(false);
        delete.setVisible(false);
    }
    @FXML
    void backclicked(MouseEvent event) throws IOException {
        Stage login = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
        Scene scene = new Scene(root);
        login.setScene(scene);
        login.show();

    }
    @FXML
    void searchclicked(ActionEvent event) throws Exception {
        LocalDate joindate ;
        String queryString = String.format("SELECT * from member where memberID = '%s'",searchmember.getText());


            Connection con = DriverManager.getConnection(ConnectionURL);
            Statement statement = con.createStatement();
            ResultSet results = statement.executeQuery(queryString);
            if (results.next()) {
                System.out.println(results.getString(1));
                memberId.setText(results.getString(1));
                firstName.setText(results.getString(2));
                surname.setText(results.getString(3));
                address.setText(results.getString(4));
                phoneNo.setText(results.getString(5));
               // gender.set(results.getString(6));
               // gender.getEditor().setText(results.getString(6));
                joindate = results.getDate(6).toLocalDate();
                        joiningdate.getEditor().setText(String.valueOf(joindate));
                //joiningdate.setPromptText(String.format(joindate, "dd/MM/YY"));
                update.setVisible(true);
                delete.setVisible(true);
            }
            else
                generateAlert(Alert.AlertType.INFORMATION, "Member Not Existed", "");




    }
    @FXML
    void deleteClicked(ActionEvent event) throws SQLException {
        updatepayment(searchmember.getText());
        String query = String.format("Delete from member where memberID = '%s'",searchmember.getText());
        Statement statement = con.createStatement();
        statement.executeQuery(query);
        memberId.setText("");
        surname.setText("");
        address.setText("");
        phoneNo.setText("");
        joiningdate.getEditor().setText("");

        generateAlert(Alert.AlertType.INFORMATION, "Member Deleted Successfully", "");


    }
    @FXML
    void updateclicked(ActionEvent event) throws SQLException {

        String name = firstName.getText();
        String query = String.format("UPDATE member SET memberID = ? , mNAME = ? , mSurname= ? , mAddress= ? , mPhoneNo= ? , mJoiningData = ? where memberID= ?");
            stmt = con.prepareStatement(query);
            stmt.setString(1,memberId.getText());
            stmt.setString(2,name);
            stmt.setString(3,surname.getText());
            stmt.setString(4,address.getText());
            stmt.setString(5,phoneNo.getText());
            stmt.setString(6,joiningdate.getEditor().getText());
            stmt.setString(7,searchmember.getText());
            stmt.execute();
        generateAlert(Alert.AlertType.INFORMATION, "Data Updated", "");



        }
        void updatepayment(String searchID) throws SQLException {
            String query2 = String.format("Delete from payment where memberID = ? ");
             stmt = con.prepareStatement(query2);
                stmt.setString(1,searchID);
                stmt.execute();
                //stmt.execute();
            generateAlert(Alert.AlertType.INFORMATION, "Deleted Successfully", "");



        }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
}


}
