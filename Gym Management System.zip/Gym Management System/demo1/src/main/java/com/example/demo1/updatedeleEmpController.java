package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class updatedeleEmpController implements Initializable {

    @FXML
    private TextField address;
    @FXML
    private TextField name;
    @FXML
    private Button ReferenceDelete;

    @FXML
    private Button delete;

    @FXML
    private TextField id;

    @FXML
    private DatePicker joindate;

    @FXML
    private TextField phoneNo;

    @FXML
    private ComboBox<String> role;

    PreparedStatement stmt;

    @FXML
    private TextField search;
    Connection con;

    @FXML
    private Button update;
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";

    @FXML
    private ComboBox<String> Trainer;

    @FXML
    void deleteClicked(ActionEvent event) throws SQLException, IOException {
        boolean check2;
        ResultSet check = con.createStatement().executeQuery(String.format("select employeeID from payment where employeeID = '%s'", search.getText()));
        if(check.next())
           check2 = true;
        else
            check2 = false;

        if (check2) {
            generateAlert(Alert.AlertType.INFORMATION, "Please Select Other Trainers for Members", "");
            String queryString2 = String.format("SELECT eName from Employee where Role = 'Trainer' and EmployeeID != '%s'", search.getText());
            Trainer.setVisible(true);
            con = DriverManager.getConnection(ConnectionURL);
            Statement statement = con.createStatement();
            ResultSet results = statement.executeQuery(queryString2);
            while (results.next())
                Trainer.getItems().add(results.getString("eName"));
            ReferenceDelete.setVisible(true);
        }
        else{
            con.createStatement().execute(String.format("Delete from Employee where EmployeeID = '%s'",search.getText()));
            generateAlert(Alert.AlertType.CONFIRMATION,"Employee Deleted Successfully ","");
        }
    }
    String id2 ;
    @FXML
    void ReferenceDeleteClicked(ActionEvent event) throws SQLException {

        String empid = String.format("Select EmployeeID from Employee where eName = '%s'",Trainer.getSelectionModel().getSelectedItem());
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(empid);
        while (results.next())
             id2 = results.getString(1);
        String query2 = String.format("Update payment SET employeeID = '%s' where employeeID = '%s'",id2,search.getText());
        con.createStatement().execute(query2);
        System.out.println("Update");
        con.createStatement().execute(String.format("DELETE from Employee where EmployeeID = '%s'",search.getText()));
        generateAlert(Alert.AlertType.CONFIRMATION,"Reference Updated and Employee Deleted","");

    }

    @FXML
    void searchClicked(ActionEvent event) throws SQLException {

        String queryString = String.format("SELECT * from Employee where EmployeeID = '%s'",search.getText());

        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        if (results.next()) {
            id.setText(results.getString(1));
            name.setText(results.getString(2));
            address.setText(results.getString(4));
            role.getEditor().setText(results.getString(5));
            phoneNo.setText(results.getString(3));
            LocalDate joiningdate = results.getDate(6).toLocalDate();
            joindate.getEditor().setText(String.valueOf(joiningdate));
            //joiningdate.setPromptText(String.format(joindate, "dd/MM/YY"));
            update.setVisible(true);
            delete.setVisible(true);
        }
        else
            generateAlert(Alert.AlertType.INFORMATION, "EMPLOYEE Not Existed", "");


    }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }
    @FXML
    void updateClicked(ActionEvent event) throws SQLException {

        // String date = joiningdate.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        String query = String.format("UPDATE Employee SET EmployeeID = ? , eName = ? ,  ePhoneNo= ? , eAddress= ? , Role = ?, eJoinDate = ? where EmployeeID= ?");
        stmt = con.prepareStatement(query);
        stmt.setString(1,id.getText());
        stmt.setString(2,name.getText());
        stmt.setString(3,phoneNo.getText());
        stmt.setString(4,address.getText());
        stmt.setString(5,role.getSelectionModel().getSelectedItem());
        stmt.setString(6,joindate.getEditor().getText());
        stmt.setString(7,search.getText());
        stmt.execute();
        generateAlert(Alert.AlertType.INFORMATION, "Data Updated", "");



    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            con = DriverManager.getConnection(ConnectionURL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        ObservableList<String> g = FXCollections.observableArrayList("Manager", "Trainer", "Sweeper");
        role.setItems(g);
        Trainer.setVisible(false);
        ReferenceDelete.setVisible(false);

    }

}
