package com.example.demo1;

import com.example.demo1.DBconnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class DashBoardController implements Initializable {

    @FXML
    private Label activeMembers;

    @FXML
    private Label earning;

    @FXML
    private Label totalMembers;
    @FXML
    private Label totalEmployees;

    private PreparedStatement pst;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String queryString = String.format("select count(memberID) as CountMember from dbo.member");
        String query2 = String.format("select count(EmployeeID) as EmployeeCount from dbo.Employee");
        String query3 = String.format("select count(memberID) as activeCount from payment where ActiveStatus = 'Active' ");
        DBconnection db = new DBconnection();
        String query = String.format(" select distinct sum(courseFee) as Income from course inner join payment on payment.courseID = course.courseID");
        showData(query);
        try {
            Statement statement = db.connectingDB();
            ResultSet results = statement.executeQuery(queryString);
            while (results.next())
                totalMembers.setText(results.getString("CountMember"));
            results = statement.executeQuery(query2);
            while (results.next())
                totalEmployees.setText(results.getString("EmployeeCount"));
            results = statement.executeQuery(query3);
            while (results.next())
                activeMembers.setText(results.getString("activeCount"));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void courseManagement(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Courses.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 700, 500);
        Stage stage = new Stage();
        stage.setTitle("Courses Managment");
        stage.setScene(scene);
        stage.show();

    }
        void showData(String query){

            DBconnection db = new DBconnection();
            try {
                Statement statement = db.connectingDB();
                ResultSet results = statement.executeQuery(query);
                while (results.next())
                    earning.setText(results.getString("Income"));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

//        connection = dbConnection.getConnection();
//        String query = "SELECT COUNT(roomNumber) AS totalRooms, a.totalNotBooked, booked.totalBooked FROM rooms, " +
//                "(SELECT COUNT(roomNumber) AS totalBooked FROM rooms WHERE status = 'Booked') AS booked, " +
//                "(SELECT COUNT(roomNumber) AS totalNotBooked FROM rooms WHERE status = 'Not Booked') AS a";
//        String query2 = "SELECT SUM(b.billAmount) AS totalEarnings, (SELECT SUM((r.price * DATEDIFF(res.checkOutDate, res.checkInDate))) AS Pending FROM reservations res \n" +
//                "INNER JOIN rooms r ON r.roomNumber = res.roomNumber \n" +
//                "WHERE res.status = 'Checked In') AS totalPendings FROM bills b \n" +
//                "INNER JOIN reservations res ON res.reservationID = b.reservationID;";
//        try {
//            pst = connection.prepareStatement(query);
//            ResultSet rs = pst.executeQuery();
//            while (rs.next()) {
//                totalRoom.setText(rs.getString("totalRooms"));
//                bookedRoom.setText(rs.getString("totalBooked"));
//                avaRoom.setText(rs.getString("totalNotBooked"));
//            }
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }
//        try {
//            pst = connection.prepareStatement(query2);
//            ResultSet rs = pst.executeQuery();
//            while (rs.next()) {
//                earning.setText(rs.getString("totalEarnings"));
//                pending.setText(rs.getString("totalPendings"));
//            }
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }
    }
}
