package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;


public class addEmpController implements Initializable {

    @FXML
    private Button addemployee2;

    @FXML
    private TextField address;

    @FXML
    private TextField id;

    @FXML
    private DatePicker joindate;

    @FXML
    private TextField name;

    @FXML
    private TextField phoneNo;

    @FXML
    private ComboBox<String> role;
    PreparedStatement stmt;
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";


    @FXML
    void employeeadd2(ActionEvent event) throws SQLException {
        Connection con = DriverManager.getConnection(ConnectionURL);
        //Statement statement = con.createStatement();
//        ResultSet results = statement.executeQuery(queryString);
//        while (results.next()){
//            cid= results.getString("courseID");
//        }
        String date = joindate.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        int id1 = Integer.parseInt(id.getText());
        String phoneno = phoneNo.getText();
        String query = String.format("INSERT INTO dbo.Employee (EmployeeID,eNAME," +
                "ephoneNo,eAddress,Role,eJoinDate) " +
                "VALUES (?,?,?,?,?,?)");
        if(isfound(id1,name.getText(),con,phoneno))
            System.out.println("Already Found");
        else {
            //if(gen.equals("Male"))
            //totalfeelabel.setText("1500");

            stmt = con.prepareStatement(query);
            stmt.setString(1, id.getText());
            stmt.setString(2, name.getText());
            stmt.setString(3, phoneno);
            stmt.setString(4, address.getText());
            stmt.setString(5, role.getSelectionModel().getSelectedItem());
            stmt.setString(6,date);
            stmt.executeUpdate();

            generateAlert(Alert.AlertType.CONFIRMATION,"Employee Added Successfully","");
        }
    }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> g = FXCollections.observableArrayList("Manager", "Trainer", "Sweeper");
        role.setItems(g);

    }
    private boolean isfound(int ID, String name,Connection con,String phoneNO) throws SQLException {
        String queryString = String.format("SELECT EmployeeID,eName FROM dbo.Employee WHERE EmployeeID='%d' OR eName='%s' AND ePhoneNo = '%s'",ID,name,phoneNO);
        Statement statement = con.createStatement();
        ResultSet results = statement.executeQuery(queryString);
        if(results.next())
            return true;
        else
            return false;

    }
}
