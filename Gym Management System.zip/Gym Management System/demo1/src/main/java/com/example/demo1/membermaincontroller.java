package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class membermaincontroller implements Initializable {

    @FXML
    void addMember(ActionEvent event) throws IOException {

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MemberDetails.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 800);
        Stage stage = new Stage();
        stage.setTitle("Dashboard");
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void delete_updateMember(ActionEvent event) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("update_deleteMem.fxml"));
        Scene scene = null;
        try {
            scene = new Scene(fxmlLoader.load(), 800, 800);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = new Stage();
        stage.setTitle("Dashboard");
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private DatePicker from;

    @FXML
    private TableView<Member> list1;

    @FXML
    private TableColumn<Member, String> madd;

    @FXML
    private TableColumn<Member, Date> mdate;

    @FXML
    private TableColumn<Member, Integer> mid;

    @FXML
    private TableColumn<Member, String> mname;

    @FXML
    private TableColumn<Member, Long> mphone;

    @FXML
    private TableColumn<Member, String> msurname;

    @FXML
    private TextField search;

    @FXML
    private DatePicker todate;
    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    PreparedStatement stmt;
    Connection con;



    @FXML
    void searchid(ActionEvent event) {
        members.clear();
        memberList.clear();
        String st = search.getText();
        String query = String.format("Select * from member where memberID = '%s'",st);
        try {
            initList(query);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        list1.setItems(members);

    }



    @FXML
    void showClicked(ActionEvent event) {

        try {
            initList("Select * from member");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        list1.setItems(members);


    }
    @FXML
    void showFromClicked(ActionEvent event) {
        String fromDate = from.getEditor().getText();
        String to = todate.getEditor().getText();
        String query = String.format("Select * from member where mJoiningData >= '%s' and mJoiningData <='%s'",fromDate,to);
        try {
            initList(query);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        list1.setItems(members);
    }
    public static final ObservableList<Member> members = FXCollections.observableArrayList();

    public static final List<Member> memberList = new ArrayList<>();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            con = DriverManager.getConnection(ConnectionURL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        mid.setCellValueFactory(new PropertyValueFactory<>("memberID"));
        mname.setCellValueFactory(new PropertyValueFactory<>("memberName"));
        msurname.setCellValueFactory(new PropertyValueFactory<>("memberSurname"));
        madd.setCellValueFactory(new PropertyValueFactory<>("memberAddress"));
        mphone.setCellValueFactory(new PropertyValueFactory<>("memberPhoneNo"));
        mdate.setCellValueFactory(new PropertyValueFactory<>("memberJoiningDate"));
        try{
            initList("Select * From member");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        list1.setItems(members);

    }
    void initList(String query) throws IOException{
        memberList.clear();
        members.clear();
        //String query = ("Select * From member");
        try {

            stmt = con.prepareStatement(query);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                int memID = result.getInt("memberID");
                String n = result.getString("mName");
                String sn = result.getString("mSurname");
                String add = result.getString("mAddress");
                long pho = result.getLong("mPhoneNo");
                Date d = result.getDate("mJoiningData");
                members.add(new Member(memID,n,sn,add,pho,d));
                memberList.add(new Member(memID,n,sn,add,pho,d));
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }

}
