package com.example.demo1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import java.io.IOException;
import java.sql.*;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.sql.ResultSet;

public class HelloController {
    String user,pass;
    boolean flag;
    Statement stmt = null;

    @FXML
    private TextField password;

    @FXML
    private Button signin;

    @FXML
    private TextField username;
    @FXML
    void ActionRegister(ActionEvent event) {

        user = username.getText();
        pass= password.getText();
        if(user.length() == 0 || pass.length() == 0)

          generateAlert(Alert.AlertType.ERROR,"PLEASE ENTER USER AND PASSWORD","");

        if(user.equals(pass))

           generateAlert(Alert.AlertType.ERROR,"PLEASE ENTER DIFFERENT USERNAME AND PASSWORD","");

        else{
            HomePageController.name = user;
        String query = String.format("INSERT INTO dbo.records (UserName, Password) VALUES ('%s', '%s')",user,pass);
        try{
            if(!isrecordfound(user,pass)) {
                stmt.execute(query); //execute query
                generateAlert(Alert.AlertType.CONFIRMATION,"ACCOUNT CREATED","");
            }
            else{
                generateAlert(Alert.AlertType.INFORMATION,"ACCOUNT ALREADY REGISTERED","");
            }
        } catch (Exception e1) {
            e1.printStackTrace();}
        }

    }

    @FXML
    void ActionSignin(ActionEvent event) throws IOException {

        user = username.getText();
        pass = password.getText();
        if(user.length() == 0 || pass.length() == 0) {
            generateAlert(Alert.AlertType.ERROR,"ERROR! Please Enter Username and Password","");
        }
        else{
        if(isrecordfound(user,pass)){
            System.out.println("Confirmed");
            signin.getScene().getWindow().hide();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HomePage.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 1000,800 );
            Stage stage = new Stage();
            stage.setTitle("Dashboard");
            stage.setScene(scene);
            stage.show();}
        else
            generateAlert(Alert.AlertType.ERROR,"WRONG USERNAME/PASSWORD !ACCESS DENIED","");
        }
    }
    private boolean isrecordfound(String user,String pass) {

        String queryString = String.format("SELECT 1 FROM dbo.records WHERE UserName='%s' AND Password='%s' ",user,pass);
        DBconnection db = new DBconnection();
        try {
            stmt=db.connectingDB();
            ResultSet results = stmt.executeQuery(queryString);
            if(results.next())
                flag=true;
            else flag=false;
        }

        catch (Exception ep) {
            System.out.println("Error " + ep.getMessage()); }
        return flag;
    }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }
}
