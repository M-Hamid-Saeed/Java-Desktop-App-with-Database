package com.example.demo1;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;

import java.io.IOException;
import java.sql.*;
import javafx.scene.*;

import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

import java.sql.ResultSet;
import java.util.ResourceBundle;

public class HelloController {
    String user,pass;
    boolean flag;
    Statement stmt = null;
    @FXML
    private AnchorPane loginPageAnchorPane;
    @FXML
    private TextField password;

    @FXML
    private Pane pnlOverview;

    @FXML
    private Button register;

    @FXML
    private Button signin;

    @FXML
    private TextField username;
    @FXML
    void ActionRegister(ActionEvent event) throws IOException {
//        Stage primarystage = (Stage) register.getScene().getWindow();
//        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("HomePage.fxml"));
//        Scene scene = new Scene(fxmlLoader.load(), 1000, 500);
//        Stage stage = new Stage();
//        stage.setTitle("Dashboard");
//        stage.setScene(scene);
//        stage.show();
//        primarystage.hide();


        user = username.getText();
        pass= password.getText().toString();
        //If user didn't enter anything
        if(user.length() == 0 || pass.length() == 0) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("ERROR");
        alert.setHeaderText("INVALID INPUT");
        alert.setContentText("Please Enter Username and Password!");
        alert.showAndWait();
        }
        if(user.equals(pass)){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("INPUT INVALID");
            alert.setHeaderText("ERROR");
            alert.setContentText("Please Enter different Username and Password");
            alert.showAndWait();
        }

        else{
            HomePageController.name = user;
        String query = String.format("INSERT INTO dbo.records (UserName, Password) VALUES ('%s', '%s')",user,pass);
        try{
            if(!isrecordfound(user,pass)) {
                stmt.execute(query); //execute query
                System.out.println("ACCOUNT CREATED");
            }
            else{
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("ERROR");
                alert.setHeaderText("Cannot Register");
                alert.setContentText("Account Already Exist");
                alert.showAndWait();
            }
        } catch (Exception e1) {
            e1.printStackTrace();}
        }

    }



    @FXML
    void ActionSignin(ActionEvent event) throws IOException {

        user = username.getText();
        pass = password.getText();
        if(user.length() == 0 || pass.length() == 0) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("ERROR");
            alert.setHeaderText("INVALID INPUT");
            alert.setContentText("Please Enter Username and Password!");
            alert.showAndWait();
        }
        else{
        if(isrecordfound(user,pass)){
            System.out.println("Confirmed");
            signin.getScene().getWindow().hide();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HomePage.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 1000,800 );
             Stage stage = new Stage();
          stage.setTitle("Dashboard");
           stage.setScene(scene);
           stage.show();


        }
        else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("ERROR");
            alert.setHeaderText("Access Denied");
            alert.setContentText("Wrong Username/Password");
            alert.showAndWait();
        }
        }


    }
    private boolean isrecordfound(String user,String pass) {

        String queryString = String.format("SELECT 1 FROM dbo.records WHERE UserName='%s' AND Password='%s' ",user,pass);
        DBconnection db = new DBconnection();
        try {
            stmt=db.connectingDB();
            ResultSet results = stmt.executeQuery(queryString);
            if(results.next())
                flag=true;
            else flag=false;
        }

        catch (Exception ep) {
            System.out.println("Error " + ep.getMessage()); }
        return flag;
    }


}
