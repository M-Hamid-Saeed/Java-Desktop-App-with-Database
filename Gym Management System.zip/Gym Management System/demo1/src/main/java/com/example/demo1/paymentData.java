package com.example.demo1;

import java.util.Date;

public class paymentData {
    private int memberid;
    private String membername;
    private String coursename;
    private float courseFee;
    private String trainername;
    private Date paymentdate;
    private String status;

    public paymentData(int memberid, String membername, String coursename, float courseFee, String trainername, Date paymentdate, String status) {
        this.memberid = memberid;
        this.membername = membername;
        this.coursename = coursename;
        this.courseFee = courseFee;
        this.trainername = trainername;
        this.paymentdate = paymentdate;
        this.status = status;
    }

    public int getMemberid() {
        return memberid;
    }

    public void setMemberid(int memberid) {
        this.memberid = memberid;
    }

    public String getMembername() {
        return membername;
    }

    public void setMembername(String membername) {
        this.membername = membername;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public float getCourseFee() {
        return courseFee;
    }

    public void setCourseFee(float courseFee) {
        this.courseFee = courseFee;
    }

    public String getTrainername() {
        return trainername;
    }

    public void setTrainername(String trainername) {
        this.trainername = trainername;
    }

    public Date getPaymentdate() {
        return paymentdate;
    }

    public void setPaymentdate(Date paymentdate) {
        this.paymentdate = paymentdate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
