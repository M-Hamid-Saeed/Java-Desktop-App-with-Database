package com.example.demo1;

import java.util.Date;

public class Employee {
    private int eid;
    private String name;
    private long phone;
    private String add;
    private String Role;
    private Date joindate;

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getPhone() {
        return phone;
    }

    public void setPhone(long phone) {
        this.phone = phone;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }

    public Date getJoindate() {
        return joindate;
    }

    public void setJoindate(Date joindate) {
        this.joindate = joindate;
    }

    public Employee(int eid, String name, long phone, String add, String role, Date joindate) {
        this.eid = eid;
        this.name = name;
        this.phone = phone;
        this.add = add;
        Role = role;
        this.joindate = joindate;
    }


}
