package com.example.demo1;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

public class employeemaincontroller implements Initializable {
    PreparedStatement stmt;
    Connection con;

    @FXML
    private TableView<Employee> empTable;

    @FXML
    private TableColumn<Employee, String> empadd;

    @FXML
    private TableColumn<Employee, Integer> empid;

    @FXML
    private TableColumn<Employee, Date> empjoindate;

    @FXML
    private TableColumn<Employee, String> empname;

    @FXML
    private TableColumn<Employee,Long> empphone;

    @FXML
    private TableColumn<Employee, String> emprole;

    @FXML
    private TextField search1;

    @FXML
    void addemployee(ActionEvent event) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("addemp.fxml"));
        Scene scene;
        try {
            scene = new Scene(fxmlLoader.load(), 620, 750);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = new Stage();
        stage.setTitle("Dashboard");
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void deleteupdateemployee(ActionEvent event) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("updateDeleteEmployee.fxml"));
        Scene scene;
        try {
            scene = new Scene(fxmlLoader.load(), 620, 750);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stage = new Stage();
        stage.setTitle("Dashboard");
        stage.setScene(scene);
        stage.show();

    }
    @FXML
    void deleteallclicked(ActionEvent event) {
        try {
           con.createStatement().execute("Delete From Employee");
        } catch (SQLException e) {
            generateAlert(Alert.AlertType.WARNING,"Please Remove References from Payment","");
            throw new RuntimeException(e);

        }


    }
    private void generateAlert(Alert.AlertType type, String header, String content){
        Alert errorAlert = new Alert(type);
        errorAlert.setHeaderText(header);
        errorAlert.setContentText(content);
        errorAlert.showAndWait();
    }

    @FXML
    void handleSearchKey(ActionEvent event) {
        try{
            initList(String.format("Select * from Employee where EmployeeID = '%s'",search1.getText()));
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        empTable.setItems(EMPLOYEES);
    }

    @FXML
    void showAllclicked(ActionEvent event) {

        try{
            initList(String.format("Select * from Employee"));
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        empTable.setItems(EMPLOYEES);
    }
    public static final ObservableList<Employee> EMPLOYEES = FXCollections.observableArrayList();

    public static final List<Employee> EMPLOYEE_LIST = new ArrayList<>();

    String ConnectionURL = "jdbc:sqlserver://HAMID\\MSSQLSERVER:1433;database=loginDatabase;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            con = DriverManager.getConnection(ConnectionURL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        empid.setCellValueFactory(new PropertyValueFactory<>("eid"));
        empname.setCellValueFactory(new PropertyValueFactory<>("name"));
        empphone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        empadd.setCellValueFactory(new PropertyValueFactory<>("add"));
        emprole.setCellValueFactory(new PropertyValueFactory<>("Role"));
        empjoindate.setCellValueFactory(new PropertyValueFactory<>("joindate"));
        try{
            initList("Select * From Employee");
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        empTable.setItems(EMPLOYEES);

    }
    void initList(String query) throws IOException{
        EMPLOYEE_LIST.clear();
        EMPLOYEES.clear();
        //String query = ("Select * From member");
        try {

            stmt = con.prepareStatement(query);
            ResultSet result = stmt.executeQuery();
            while (result.next()) {
                int memID = result.getInt("EmployeeID");
                String n = result.getString("eName");
                long pho = result.getLong("ePhoneNo");
                String add = result.getString("eAddress");
                String role = result.getString("Role");
                Date d = result.getDate("eJoinDate");
                EMPLOYEES.add(new Employee(memID,n,pho,add,role,d));
                EMPLOYEE_LIST.add(new Employee(memID,n,pho,add,role,d));
            }
        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}
