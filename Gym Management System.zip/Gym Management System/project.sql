CREATE TABLE Employee(
	EmployeeID int primary key NOT NULL,
	eName varchar(30) NOT NULL,
	ePhoneNo varchar(12) NOT NULL,
	eAddress varchar(20) NULL,
	eGender varchar(10) NOT NULL,
	Role varchar(15) not null,
	
)
select member.memberID,member.mName,course.courseName,courseFee,Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID)
--payment.memberID,member.mName,Employee.eName,course.courseName ,payment.paymentDate,payment.ActiveStatus
select distinct member.memberID,member.mName,course.courseFee,Employee.eName,payment.paymentDate,payment.ActiveStatus from member join payment on (member.memberID = payment.memberID) join course on (course.courseID = payment.courseID) join Employee on(payment.employeeID = Employee.EmployeeID) 

create table course(
courseID int primary key not null,
courseName varchar(20),
courseFee float 


)
insert into course values(3,'Body',3000.0)
select * from course
drop table Employee

ALTER TABLE member add courseID int foreign key references course(courseID)
ALTER TABLE member drop column EmployeeID
ALTER TABLE payment
ADD FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID);
alter table payment drop foreign key (EmployeeID) references Employee(EmployeeID)
use loginDatabase
select * from payment
select CONSTRAINT_NAME
from INFORMATION_SCHEMA.TABLE_CONSTRAINTS
where TABLE_NAME = 'payment';

select * from employee

create table RegisterMember(
 memberID int foreign key references member(memberID),
 courseID int foreign key references course(courseID),
 ActiveStatus varchar(10)
 
)
create table payment(
--paymentID int primary key not null,
 memberID int foreign key references member(memberID),
 employeeID int foreign key references Employee(EmployeeID),
  courseID int foreign key references course(courseID),
  paymentDate date,
 ActiveStatus varchar(10),

 )
 
 alter table member drop column mGender
 use loginDatabase
 drop table payment
 select * from Employee

 use loginDatabase
 select * from payment
 select * from member
 select * from member where mJoiningData >= '2022-05-29' and mJoiningData<= '2022-06-06'
 select * from payment where memberID in (SELECT  distinct memberID FROM payment)
SELECT  distinct memberID FROM payment Order by memberID;
 select distinct sum(courseFee) as Income from course inner join payment on payment.courseID = course.courseID where payment.paymentDate >= '2022-05-29' and payment.paymentDate<= '2022-06-06' 